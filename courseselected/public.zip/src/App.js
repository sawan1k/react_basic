import React, { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import Filter from "./components/Filter";
import Cards from "./components/Cards";
import Spinner from "./components/Spinner";
import { apiUrl, filterData } from "./data";
import { toast } from "react-toastify";

const App = () => {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  async function fetchData() {
    setLoading(true);
    try {
      let response = await fetch(apiUrl);
      let result = await response.json();
      console.log(result);
      //save data
      setCourses(result.data);
    } catch (error) {
      toast.error("Something went wrong");
    }
    setLoading(false);
  }
  useEffect(() => {
    fetchData();
  }, []);
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <Filter filterData={filterData} />

      <div>{loading ? <Spinner /> : <Cards course={courses} />}</div>
    </div>
  );
};

export default App;
